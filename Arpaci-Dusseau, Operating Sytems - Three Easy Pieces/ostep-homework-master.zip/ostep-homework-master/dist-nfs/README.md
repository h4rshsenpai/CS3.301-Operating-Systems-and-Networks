# README

Traces can be found here:
http://iotta.snia.org/traces/nfs

Included here is one sample trace from the Berkeley Auspex traces therein.

Enjoy?
